
set +x

export RUN_SH_PATH=/app/pushEngine/REMOTING/rmt_pe/code_build_deploy/
cd $RUN_SH_PATH


./run.sh rmtnode1@rdd-dev4app.ebiz.verizon.com 8050 $1 pe_rmt_01