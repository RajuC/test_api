
set +x
export RUN_SH_PATH=/app/pushEngine/REMOTING/rmt_pe/code_build_deploy/

cd $RUN_SH_PATH


# ./run.sh rmtnode1@pws111dev.hss.vzwcorp.com 8050 $1 pe_rmt_01

./run.sh rmtnode1@rdd-dev1app.ebiz.verizon.com 8050 $1 pe_rmt_01



## export PATH=$PATH:/app/erlang/20.1/bin/; ./run.sh rmtnode1@rdd-dev1web.ebiz.verizon.com 8050 start pe_rmt_01


# ./run.sh rmtnode1@rdd-dev1web.ebiz.verizon.com 8050 start pe_rmt_01

# ./run.sh rmtnode2@rdd-dev1web.ebiz.verizon.com 8051 start pe_rmt_02
# =============
# ./run.sh rmtnode1@rdd-dev2web.ebiz.verizon.com 8050 start pe_rmt_01

# ./run.sh rmtnode2@rdd-dev2web.ebiz.verizon.com 8051 start pe_rmt_02
# ==============
# ./run.sh rmtnode1@rdd-dev3web.ebiz.verizon.com 8050 start pe_rmt_01

# ./run.sh rmtnode2@rdd-dev3web.ebiz.verizon.com 8051 start pe_rmt_02
# ============
# ./run.sh rmtnode1@rdd-dev4web.ebiz.verizon.com 8050 start pe_rmt_01

# ./run.sh rmtnode2@rdd-dev4web.ebiz.verizon.com 8051 start pe_rmt_02