
set +x

export RUN_SH_PATH=/app/pushEngine/REMOTING/rmt_pe/code_build_deploy/
cd $RUN_SH_PATH


# ./run.sh rmtnode2@pws111dev.hss.vzwcorp.com 8051 $1 pe_rmt_02

./run.sh rmtnode2@rdd-dev1app.ebiz.verizon.com 8051 $1 pe_rmt_02