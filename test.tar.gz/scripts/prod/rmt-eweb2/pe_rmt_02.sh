set +x

export RUN_SH_PATH= /app/
INPUT_CMD=`echo $1 | tr "[A-Z]" "[a-z]"`

case $1 in
	start)
	  	export INPUT_CMD=start
	  	;;
	startbg)
	  	export INPUT_CMD=start
	  	;;
	startfg)
	  	export INPUT_CMD=console
	  	;;
	stop)
	  	export INPUT_CMD=stop
	  	;;	
	*)
	  	echo "Please enter a proper command!!! - start/startbg/startfg/stop"
	  	;;
esac


echo "============== input command"
echo $INPUT_CMD

./run.sh rmtnode2@rmt-eweb2.odc.vzwcorp.com 8051 $INPUT_CMD