set +x

export PATH=$PATH:/app/erlang/20.1/bin/

ls -lrth

PE_PATH=remote_view/push_engine

export http_proxy=http://proxy.ebiz.verizon.com:80
export https_proxy=http://proxy.ebiz.verizon.com:80


cd $PE_PATH

chmod +x rebar3 code_build_deploy/*.sh
# chmod +x scripts_conf/*/*/*/*.sh
chmod +x scripts/*/*/*.s


echo " Building Release for Remote View ================="
./rebar3 release
echo " Building Release for Remote View PE Completed...... ================="

echo "{\"App-Title\":\"rmt_pe\",\"App-Version\":\"${BUILD_NUMBER}\",\"Built-By\":\"chitra2\",\"Build-Branch\":\"${Branch}\",\"Build-Id\":\"${BUILD_NUMBER}\",\"Build-Number\":\"${BUILD_NUMBER}\",\"Build-Time\":\"${BUILD_TIMESTAMP}\",\"Implementation-Version\":\"${BUILD_NUMBER}\",\"Implementation-Vendor\":\"Verizon\",\"Implementation-Title\":\"rmt_pc\"}" >> ${WORKSPACE}/remote_view/push_engine/build_info.json

mkdir -p ${WORKSPACE}/target/codedeploy/rmt_pe

ls -lrth  ${WORKSPACE}/target/codedeploy/*
cp -r ${WORKSPACE}/remote_view/push_engine/* ${WORKSPACE}/target/codedeploy/rmt_pe


cd  ${WORKSPACE}/target/codedeploy
rm -rf *_*.zip
zip -q -T -m ../rmt_pe_${BUILD_NUMBER}.zip -r * .[^.]*  && echo "zipping and build success...." || echo "zipping and build failure...."