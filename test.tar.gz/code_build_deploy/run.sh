#!/bin/bash
set +x

export RELX_REPLACE_OS_VARS=true
# ERL_EPMD_PORT=14300
ERL_EPMD_PORT=13300

export PORT_RANGE_MIN=13301
export PORT_RANGE_MAX=13499

export ERL_EPMD_PORT
export INPUT_CMD=`echo $3 | tr "[A-Z]" "[a-z]"`
export PE_PATH=/app/pushController/REMOTING/mvmdremoting/remote_view/push_engine
export PE_REL_PATH=_build/default/rel/push_engine/bin/push_engine
export RMT_LOG_PATH=/log/pushEngine/REMOTING
export SERVER_NAME=$4
RMT_LOG_DIR=$RMT_LOG_PATH/$SERVER_NAME/logs/
export RMT_LOG_DIR

## ./run.sh rmtnode1@pws111dev.hss.vzwcorp.com 8050 start/startfg/stop pe_rmt_01

echo ""
echo ""

echo "NODE_NAME: 		-------------> $1"
echo "PORT NUMBER: 		-------------> $2"
echo "SHELL COMMAND:   	-------------> $3"



echo ""
echo ""


case $INPUT_CMD in
	start)
		cd $PE_PATH/
	  	NODE_NAME=$1 PORT=$2 LOG_ROOT=$RMT_LOG_DIR ./$PE_REL_PATH start
	  	;;
	startbg)
	  	cd $PE_PATH/
	  	NODE_NAME=$1 PORT=$2 LOG_ROOT=$RMT_LOG_DIR ./$PE_REL_PATH start
	  	;;
	startfg)
	  	cd $PE_PATH/
	  	NODE_NAME=$1 PORT=$2 LOG_ROOT=$RMT_LOG_DIR ./$PE_REL_PATH console
	  	;;
	status)
		export RMT_PID=`alias grep='grep' | ps aux | grep beam | grep $1 | awk '{print $2}'`
		if [ -z "${RMT_PID}" ];
			then     echo "$1 is not running..!";
			else     echo "PID: $RMT_PID|| Node Name: $1 ||Port: $2 || Status: Running...!";
		fi
	  	;;	  	
	stop)
		export RMT_PID=`alias grep='grep' | ps aux | grep beam | grep $1 | awk '{print $2}'`
		if [ -z "${RMT_PID}" ];
			then     echo "$1 is not running- Nothing to stop..!";
			else     kill -9 $RMT_PID; echo "PID: $RMT_PID|| Node Name: $1 ||Port: $2 || Status: Stopped...!";
		fi
	  	;;
	shutdown)
		export RMT_PID=`alias grep='grep' | ps aux | grep beam | grep $1 | awk '{print $2}'`
		if [ -z "${RMT_PID}" ];
			then     echo "$1 is not running- Nothing to stop..!";
			else     kill -9 $RMT_PID; echo "PID: $RMT_PID|| Node Name: $1 ||Port: $2 || Status: Stopped...!";
		fi
	  	;;		  	
	*)
	  	echo "Please enter a proper command!!! - status/start/startbg(background)/startfg(foreground-shell)/stop/shutdown/";
	  	;;
esac


