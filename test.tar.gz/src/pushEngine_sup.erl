%% Feel free to use, reuse and abuse the code in this file.

%% @private
-module(pushEngine_sup).
-behaviour(supervisor).
% -include("comet_logger.hrl").

%% API.
-export([start_link/0]).

%% supervisor.
-export([init/1]).

%% API.

-spec start_link() -> {ok, pid()}.


start_link() ->
	supervisor:start_link({local, ?MODULE}, ?MODULE, []).

%% supervisor.

init([]) ->
	% Elogger = {elogger, {elogger, start_link, []}, 
	% 		   permanent, 5000, worker, [elogger]},
	
	AdminInt = {admin_interface, {admin_interface, start, []},
				permanent, 5000, worker, [admin_interface]},
	
	% comet_logger:load_env_variables(),
	
	% %specify comet_disk_log child process (should come before comet_logger child processes in process list)
	% Comet_disk_log = {comet_disk_log, {comet_disk_log, start_link, []}, 
	% 				  permanent, 5000, worker, [comet_disk_log]},
	
	% Lb_Kal_Ok = {?SERVER_LOG_LB_KAL_OK, {comet_logger, start_link, [{?SERVER_LOG_LB_KAL_OK, ?STR_LOG_LB_KAL_OK}]}, 
	% 			 permanent, 5000, worker, [comet_logger]},
	% Lb_Kal_No_Pc = {?SERVER_LOG_LB_KAL_NO_PC, {comet_logger, start_link, [{?SERVER_LOG_LB_KAL_NO_PC, ?STR_LOG_LB_KAL_NO_PC}]}, 
	% 				permanent, 5000, worker, [comet_logger]},
	% Gslb_Kal_Ok = {?SERVER_LOG_GSLB_KAL_OK, {comet_logger, start_link, [{?SERVER_LOG_GSLB_KAL_OK, ?STR_LOG_GSLB_KAL_OK}]}, 
	% 			   permanent, 5000, worker, [comet_logger]},
	% Gslb_Kal_No_Pc = {?SERVER_LOG_GSLB_KAL_NO_PC, {comet_logger, start_link, [{?SERVER_LOG_GSLB_KAL_NO_PC, ?STR_LOG_GSLB_KAL_NO_PC}]}, 
	% 				  permanent, 5000, worker, [comet_logger]},
	%%NOTE: Elogger should be before the others
	% Procs = [	Elogger,Comet_disk_log, Lb_Kal_Ok, Lb_Kal_No_Pc, Gslb_Kal_Ok, Gslb_Kal_No_Pc,AdminInt],
	
	{ok, {{one_for_one, 10, 10}, [AdminInt]}}.
