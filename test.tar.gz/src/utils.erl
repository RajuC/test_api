-module(utils).

%% ====================================================================
%% API functions
%% ====================================================================
-export([get_pc_node/1,
		 logDeviceConnect/1,
		 logDeviceDisconnect/2,
		 logPEProcessExit/2,
		 get_timestamp/0,
		 write_to_file/1,selectpcnodes/0]).


get_pc_node(PushId) ->
	get_pc_node(PushId , os:getenv("TEST_ALONE")).

get_pc_node(PushId, false) ->
	Pclist = selectpcnodes(),
	Length = length(Pclist),
	if   Length > 0 ->
			 Num = getOwnRandom(PushId, Length),
			 lists:nth(Num, Pclist);
		 true ->
			 {error, not_found}
	end;
get_pc_node(_PushId, _) ->
	node().
	
% return a list of available push controller nodes.
selectpcnodes() ->
	Nodelist = nodes(connected),
	% process_list(Nodelist,[]).
	filter_pcnodes(Nodelist,[]).

filter_pcnodes([],OutputList) ->
	{_List1, _List2, FilteredAtomList} = lists:unzip3(OutputList),
	FilteredAtomList;

filter_pcnodes(NodeList, OutputList) ->	
	[NodeNameAtom|T] = NodeList,
	NodeName = atom_to_list(NodeNameAtom),
	ParsedResult = string:tokens(NodeName, "N _ G @"),
	NewOutputList =
		if 
			length(ParsedResult) == 5 ->
				[P1, _P2, P3, P4, _P5] = ParsedResult,
				if
					P1 == "rmtnode" ->
						Res1 = lists:keyfind(P4, 2, OutputList),
						case P3 of
							"Pri" ->
								if 
									Res1 == false ->
										lists:append(OutputList, [{P3, P4, NodeNameAtom}]);
									true ->
										TempList = lists:delete(Res1, OutputList),
										lists:append(TempList, [{P3, P4, NodeNameAtom}])
								end;
							"Sec" ->
								if 
									Res1 == false ->
										lists:append(OutputList, [{P3, P4, NodeNameAtom}]);
									true ->
										OutputList
								end;
							_Other ->
								OutputList
						end;
					true ->
						OutputList
				end;
			true ->
				OutputList
		end,
	filter_pcnodes(T, NewOutputList).

getOwnRandom(PushId, Num) ->
	Num1 = (catch list_to_integer(PushId)),
	Num2 =
		if 
			erlang:is_integer(Num1) ->
				%Num1 is a valid integer
				Num1;
			true ->
				%Not a valid integer - need to hash and get int value
				erlang:phash2(PushId)
		end,
	(Num2 rem Num) + 1.

%% logDeviceConnect() - Prints to the log via error_logger when a client connects. 
logDeviceConnect(PushId) ->	
	case  erlang:is_list(PushId) of
		false ->
			lager:info("||DeviceConnecting InvalidPUSHID: PushID = ~p.~n",[PushId]);
		true ->			
			LogString = "||Device connected: PUSHID = " ++ PushId ++ "\n",
			lager:info(LogString)
	end.

%% logDeviceDisconnect() -	Prints to the log via error_logger when a client disconnects. 
logDeviceDisconnect(PushId, Reason) ->
	case  erlang:is_list(PushId) of
		false ->			
			noop;		
		true ->			
			LogString = "||Device disconnected: PUSHID = " ++ PushId ++ "    Reason = " ++ Reason ++ "\n",
			lager:info(LogString)
	end.



logPEProcessExit(PushId, Reason) ->
	
	LogString = "||PEProcess Exited: PUSHID = " ++ PushId ++ "    Reason = " ++ Reason ++ "\n",
	lager:info(LogString).


get_timestamp() ->
	{MegaSecs, Secs, MicroSecs} = os:timestamp(),
	(MegaSecs*1000000000) + (Secs * 1000) + trunc(MicroSecs/1000).


write_to_file(ScreenData) ->
	{ok, IoDevice} = file:open("screen.png", [write]),
	file:write(IoDevice, ScreenData),
	file:close(IoDevice).