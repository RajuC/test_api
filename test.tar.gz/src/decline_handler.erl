%% @author sarwaah
%% @doc @todo Add description to decline_handler.


-module(decline_handler).

-export([init/2]).

-record (state,{pc_pid,
				pc_node,
				connect_timer,
				ack_timers = [],
				resp_timers = []}).

-record('DeviceParameters',{push_id, token, imsi, imei, iccid, meid, mvmVersion, 
							mvsVersion, make, model, firmware, x_resol, y_resol, compress,featureList,client_status}).

%% ====================================================================
%% API functions
%% ====================================================================

init(Req,Opts) ->
	% Path = cowboy_req:path(Req),
	% Host_URL = cowboy_req:host_url(Req),
	% lager:info("|| URL: ~p Path: ~p",[Host_URL,Path]),
	lager:info("||PE pid = ~p init websocket Req: ~p",[self(), Req]),
	DeviceParams 	= get_device_params(Req),
	PushId 			= DeviceParams#'DeviceParameters'.push_id,
	PCNode 			= utils:get_pc_node(PushId),
	
	case send_connect_to_pc(PCNode, DeviceParams,Req) of
		{connect_success,State,Resp} ->
			pc_response_handle(State,DeviceParams),
			{ok, Resp, Opts};
		{connect_failed,Resp}->
			{ok, Resp, Opts}
	end.


	
%% ====================================================================
%% Internal functions
%% ====================================================================

send_connect_to_pc(PCNode, Parameters,Req) ->
	{locator_gen_server, PCNode} ! {connect_request, Parameters#'DeviceParameters'.push_id, self(), Parameters},

	receive
		{cr,_,PcPid,Site} ->
			lager:info("||Received success (cr) from PC with LRP PID, sending success msg to client."),
			{connect_success,#state{pc_pid=PcPid, pc_node=Site},cowboy_req:reply(200,[],[],Req)};
		{cf,112} ->
			lager:info("||Received failure (cf-112) from PC, sending failure msg to client."),
			{connect_failed,cowboy_req:reply(400,[],[],Req)};		
		lrp_not_found ->
			lager:info("||Received failure (lrp_not_found) from PC, sending failure msg to client."),
			{connect_failed,cowboy_req:reply(501,[],[],Req)};
		no_resp_grp ->
			lager:info("||Received failure (no_resp_grp) from PC, sending failure msg to client."),
			{connect_failed,cowboy_req:reply(501,[],[],Req)}
	end.


pc_response_handle(State,Params) ->
	PcPid = State#state.pc_pid,
	lager:info("||Sending Timeout/Declined Msg to PC LRP, LRP PID is: ~p.",[PcPid]),
	PcPid ! {clientDeclined, Params#'DeviceParameters'.client_status, self()},
	receive
		statusDeliveredToUI ->
			ok;
		_ ->
			noop
	end.
	


get_device_params(Req) ->
	#'DeviceParameters'{
						push_id 		= get_req_list(<<"mdn">>, 			Req),
						token 			= get_req_list(<<"token">>, 		Req),
						imsi 			= get_req_list(<<"imsi">>, 			Req),
						imei 			= get_req_list(<<"imei">>, 			Req),
						iccid 			= get_req_list(<<"iccid">>, 		Req),
						meid 			= get_req_list(<<"meid">>, 			Req),
						mvmVersion 		= get_req_list(<<"mvmversion">>, 	Req),
						mvsVersion 		= get_req_list(<<"mvsversion">>, 	Req),
						make 			= get_req_list(<<"make">>, 			Req),
						model 			= get_req_list(<<"model">>, 		Req),
						firmware 		= get_req_list(<<"firmware">>, 		Req),
						x_resol 		= get_req_list(<<"x">>, 			Req),
						y_resol 		= get_req_list(<<"y">>, 			Req),
						compress 		= get_req_list(<<"cr">>, 			Req),
						featureList 	= get_req_list(<<"featurelist">>, 	Req),
					   	client_status 	= get_req_list(<<"status">>, 		Req)
					   }.


get_req_list(Type, Req) ->
	case cowboy_req:header(Type, Req) of
		undefined ->
			undefined;
		Bin ->
			binary_to_list(Bin)
	end.
	
	
