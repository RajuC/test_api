%% @author sarwaah
%% @doc @todo Add description to decline_handler.


-module(prews_msg_handler).

-export([init/2, send_connect_to_pc/3]).

-record (state,{pc_pid,
                pc_node,
                connect_timer,
                ack_timers = [],
                resp_timers = []}).

-record('DeviceParameters',{push_id, token, imsi, imei, iccid, meid, mvmVersion,
                            mvsVersion, make, model, firmware, x_resol, y_resol, compress,featureList,client_status}).

%% ====================================================================
%% API functions
%% ====================================================================

init(Req,Opts) ->
    Path          = cowboy_req:path(Req),
    Host_URL      = cowboy_req:host_url(Req),
    lager:info("||URL: ~p Path: ~p",[Host_URL,Path]),
    lager:info("||PE pid = ~p init websocket Req: ~p ",[self(),Req]),
    DeviceParams  = get_device_params(Req),
    PushId        = DeviceParams#'DeviceParameters'.push_id,
    Status        = DeviceParams#'DeviceParameters'.client_status,
    PCNode        = utils:get_pc_node(PushId),
    Arrival_time  = get_req_list(<<"arrival_time">>, Req),
    Token         = DeviceParams#'DeviceParameters'.token,
    OsType        = get_req_list(<<"OS_TYPE">>,         Req),
    AppId         = get_req_list(<<"APP_ID" >>,         Req),
    AppVersion    = get_req_list(<<"APP_VERSION" >>,    Req),
    DeviceModel   = get_req_list(<<"DEVICE_MODEL" >>,   Req),
    OsVersion     = get_req_list(<<"OS_VERSION" >>,    Req),
    
    lager:info("||[~p] Path: ~p, PushId: ~p, PCNode: ~p, Token: ~p, SMS/WAP Arrival time: ~p Status: ~p OS_TYPE: ~p
                          APP_ID: ~p APP_VERSION: ~p DEVICE_MODEL: ~p OS_VERSION: ~p ",
                          [self(), Path, PushId, PCNode, Token, Arrival_time, Status, OsType, AppId, AppVersion, DeviceModel, OsVersion]),  
    Req2 =    
        case Path of
            <<"/rmt/decline">> ->
                lager:info("||[~p] Valid Path.. Path: ~p, PushId: ~p, Status: ~p ", [self(), Path, PushId, Status]),
                cowboy_req:reply(200,[],[],Req),
                send_to_pc_pid(PCNode, DeviceParams, Status);
            <<"/rmt/deviceMsg">> ->
                case validate_status(Status) of
                    valid ->
                        lager:info("||[~p] Valid Path and Status.. Path: ~p, PushId: ~p, Status: ~p ", [self(), Path, PushId, Status]),
                        cowboy_req:reply(200,[],[],Req),
                        send_to_pc_pid(PCNode, DeviceParams, Status);
                    invalid ->
                        lager:info("||[~p] Valid Path and Invalid Status.. Path: ~p, PushId: ~p, Status: ~p ", [self(), Path, PushId, Status]),
                        cowboy_req:reply(500,[],[],Req)
                end;
            _OtherPath ->
                lager:info("||[~p] Invalid Path.. Path: ~p PushId: ~p, Status: ~p ", [self(), Path, PushId, Status]),
                cowboy_req:reply(500,[],[],Req)
        end,
    {ok, Req2, Opts}.



%% ====================================================================
%% Internal functions
%% ====================================================================

send_connect_to_pc(PCNode, Parameters,Req) ->
    {locator_gen_server, PCNode} ! {connect_request, Parameters#'DeviceParameters'.push_id,self(), Parameters},
    
    receive
        {cr,_,PcPid,Site} ->
            lager:info("||Received success (cr) from PC with LRP PID, sending success msg to client."),
            {connect_success,#state{pc_pid=PcPid, pc_node=Site}, cowboy_req:reply(200,[],[],Req)};
        {cf,112} ->
            lager:info("||Received failure (cf-112) from PC, sending failure msg to client."),
            {connect_failed,cowboy_req:reply(400,[],[],Req)};
        lrp_not_found ->
            lager:info("||Received failure (lrp_not_found) from PC, sending failure msg to client."),
            {connect_failed,cowboy_req:reply(501,[],[],Req)};
        no_resp_grp ->
            lager:info("||Received failure (no_resp_grp) from PC, sending failure msg to client."),
            {connect_failed,cowboy_req:reply(501,[],[],Req)};
        _ ->
            lager:info("||Unknown Response Received from PC, sending failure msg to client."),
            {connect_failed,cowboy_req:reply(501,[],[],Req)}
    end.

send_to_pc_pid(PCNode, DeviceParams, Status) ->
    lager:info("||PushId: ~p, PCNode:~p, Status:~p.",
                          [ DeviceParams#'DeviceParameters'.push_id, PCNode, Status]),
    {locator_gen_server, PCNode} ! {sending_to_pc, DeviceParams#'DeviceParameters'.push_id,self(), Status, DeviceParams},
    receive
        Other ->
            lager:info("||Received: ~p.",[Other]),
            ok
    end.


% pc_response_handle(State,Params) ->
%   PcPid = State#state.pc_pid,
%   lager:info("||Sending pre_ws Msg to PC LRP, LRP PID is: ~p.",[ PcPid]),
%   PcPid ! {preWSClientMsg, list_to_binary(Params#'DeviceParameters'.client_status),self()},
%   receive
%       statusDeliveredToUI -> ok;
%       _ -> noop
%   end.

%     device_status_pc_response_handle(State,Params) ->
% PcPid = State#state.pc_pid,
%      lager:info("||Sending pre_ws Msg to PC LRP, LRP PID is: ~p.",[ PcPid]),
%      PcPid ! {preWSClientMsg, list_to_binary(Params#'DeviceParameters'.client_status),self()},
%      receive
%   statusDeliveredToUI -> ok;
%   _                   ->  noop
%      end.



get_device_params(Req) ->
    Status =
        case get_req_list(<<"status">>, Req) of
            "RemoteViewtConsentShown"  -> "RemoteViewConsentShown";
            "Declined "                -> "Declined";
            "TimedOut "                -> "TimedOut";
            Status1                    -> Status1
        end,
    #'DeviceParameters'{
                        push_id             = get_req_list(<<"mdn">>,           Req),
                        token               = get_req_list(<<"token">>,         Req),
                        imsi                = get_req_list(<<"imsi">>,          Req),
                        imei                = get_req_list(<<"imei">>,          Req),
                        iccid               = get_req_list(<<"iccid">>,         Req),
                        meid                = get_req_list(<<"meid">>,          Req),
                        mvmVersion          = get_req_list(<<"mvmversion">>,    Req),
                        mvsVersion          = get_req_list(<<"mvsversion">>,    Req),
                        make                = get_req_list(<<"make">>,          Req),
                        model               = get_req_list(<<"model">>,         Req),
                        firmware            = get_req_list(<<"firmware">>,      Req),
                        x_resol             = get_req_list(<<"x">>,             Req),
                        y_resol             = get_req_list(<<"y">>,             Req),
                        compress            = get_req_list(<<"cr">>,            Req),
                        featureList         = get_req_list(<<"featurelist">>,   Req),
                        client_status       = Status
                       }.


get_req_list(Type, Req) ->
    case cowboy_req:header(Type, Req) of
        undefined ->
            undefined;
        Bin ->
            binary_to_list(Bin)
    end.


validate_status("UserClickedLink")                  -> valid;
validate_status("RemoteConnectConsentShown")        -> valid;
validate_status("notificationTimedOut")             -> valid;
validate_status("RemoteViewConsentShown")           -> valid;
validate_status("bothMsgShown")                     -> valid;
validate_status("notificationMsgShown")             -> valid;
validate_status("photoMsgShown")                    -> valid;
validate_status("permissionsFixed")                 -> valid;
validate_status("StartingRemoteView")               -> valid;
validate_status("RemoteViewtConsentShown")          -> valid;
validate_status("AlreadyConnected")                 -> valid;
validate_status("SkippedRequest")                   -> valid;
validate_status("Declined")                         -> valid;
validate_status("TimedOut")                         -> valid;
validate_status("WebsocketConnectionFailed")        -> valid;
validate_status("StartingRemoteViewWithReplayKit")  -> valid;
validate_status(_OtherStatus)                       -> invalid.