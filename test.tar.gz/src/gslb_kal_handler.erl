-module(gslb_kal_handler).
% -include("comet_logger.hrl").
-export([init/2,terminate/3]).
-define(GSLB_WAITTIME, 10000).

init(Req, Opts) ->
	% Path = cowboy_req:path(Req),
	% Host_URL = cowboy_req:host_url(Req),
	% lager:info("||URL: ~p Path: ~p",[Host_URL,Path]),
	% lager:info("||received gslb_kal ",[]),
	Pclist = utils:selectpcnodes(),
	% lager:info("||Pelist is ~p", [Pelist]),
	Length = length(Pclist),
	Resp =
	if Length >= 2 ->		   
%% 		   Socket = Req:get(socket),
%% 		   inet:setopts(Socket,[{active, true},{packet, line}]),
		   Num = rand:uniform(Length),
		   SelectedNode = lists:nth(Num, Pclist),				                                 
		   %lager:info("||Time: ~p, push engine sent gslb_request to push controller", [erlang:timestamp()]),
		   {locator_gen_server, SelectedNode}!{gslb_request, self()},
		   receive
			   {gslb_ack, GSLB_Result} ->
				   case GSLB_Result of
					   success ->
					   		health:info("||gslb/kal- return ok"),
						    cowboy_req:reply(200,[],[],Req);
						    % lager:info("||Time: ~p, push engine responds 200 OK for gslb request", [erlang:timestamp()]),
						   
						    % ?LOG_GSLB_KAL_OK();
					   fail ->
						   lager:info("||Time: ~p, push engine get {}gslb_ack, fail}, responds 502 for gslb request", [erlang:timestamp()]),
					   	   cowboy_req:reply(502,[],[],Req);
					   _Other ->
						    lager:info("||Time: ~p, push engine get {}gslb_ack, ~p}, responds 502 for gslb request", [erlang:timestamp(), _Other]),
						    cowboy_req:reply(502,[],[],Req)
				   end
		   after ?GSLB_WAITTIME ->
			   lager:info("||Time: ~p, for GSLB request, push engines didn't get response from controller in ~p milliseconds, sends 502",
			   		[erlang:timestamp(), ?GSLB_WAITTIME]),
			   cowboy_req:reply(502,[],[],Req)
		   end;
	   true ->
		   lager:info("||Time: ~p, number of push controller nodes is ~p, doesn't achieve GSLB request",[erlang:timestamp(), Length]),
		   % ?LOG_GSLB_KAL_NO_PC()
		   health:error("||No PC - return 502 for gslb-kal"),
		   cowboy_req:reply(502,[],[],Req)
	end,
	{ok, Resp, Opts}.



%% 		   ?LOG_GSLB_KAL_OK(),
%% 		   lager:info("||gslb/kal ok", []),
%% 		   Resp = cowboy_req:reply(200,[],[],Req);
%% 	   true ->
%% 		   % no push engine is connected, return error code 502 which means "Bad Gateway"
%% 		   ?LOG_GSLB_KAL_NO_PE(),
%% 		   lager:info("||gslb/kal no PE  ", []),
%% 		   Resp = cowboy_req:reply(502,[],[],Req)
%% 	end,
%% 	{ok, Resp, Opts}.

terminate(_Reason, _Req, _State) ->
	ok.

