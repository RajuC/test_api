-module(lb_kal_handler).
% -include("comet_logger.hrl").
-export([init/2,terminate/3]).

init(Req, Opts) ->
	% Path = cowboy_req:path(Req),
	% Host_URL = cowboy_req:host_url(Req),
	Pclist = utils:selectpcnodes(),
	% lager:info("||Pelist is ~p", [Pelist]),
	Length = length(Pclist),
	Resp =
		if Length > 0 ->
			   % ?LOG_LB_KAL_OK(),
			   health:info("||lb/kal return OK"),
			   %lager:info("||lb/kal OK  ", []),
			   cowboy_req:reply(200,[],[],Req);
		   true ->
			   % no push engine is connected, return error code 502 which means "Bad Gateway"
			   % ?LOG_LB_KAL_NO_PC(),
			   health:error("||No PC - return 502 for lb-kal"),
			   %lager:info("||lb/kal no PC  ", []),
			   cowboy_req:reply(502,[],[],Req)
		end,
	{ok, Resp, Opts}.

terminate(_Reason, _Req, _State) ->
    ok.

