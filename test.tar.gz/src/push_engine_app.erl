%%%-------------------------------------------------------------------
%% @doc push_engine public API
%% @end
%%%-------------------------------------------------------------------

-module(push_engine_app).

-behaviour(application).

%% Application callbacks
-export([start/2, stop/1]).

%%====================================================================
%% API
%%====================================================================

% start() ->
% 	ws_handler:dummy_pc(),
% 	[application:start(A)||A<-[ranch,crypto,cowlib,cowboy,pushEngine]].

start(_Type, _Args) ->
		Dispatch = cowboy_router:compile([
									  {'_', [
%%											 {"/", cowboy_static, {priv_file, pushEngine, "index.html"}},
											 {"/rmt/push", ws_handler, []},
											 {"/rmt/decline",prews_msg_handler,[]},
											 {"/rmt/deviceMsg",prews_msg_handler,[]},
											 {"/lb/kal", lb_kal_handler, []},
											 {"/gslb/kal", gslb_kal_handler, []},
											 {"/rmt/lb/kal", lb_kal_handler, []},
											 {"/rmt/gslb/kal", lb_kal_handler, []},
											 {"/static/[...]", cowboy_static, {priv_dir, pushEngine, "static"}}
											]}
									 ]),
	{ok, _} = cowboy:start_clear(http,[{port, get_port()}], #{
				env => #{dispatch => Dispatch}
	}),
	application:set_env(kernel, inet_dist_listen_min,13300),
	application:set_env(kernel, inet_dist_listen_max,13499),
	pushEngine_sup:start_link().

stop(_State) ->
	ok.
%%====================================================================
%% Internal functions
%%====================================================================



get_port() ->
        case application:get_env(push_engine, port) of
            % {ok,"${PORT}"}  ->    lager:error("||Fetching Env vars Failed||sys.config error"),
            % 					  8000;
            {ok, Port}     ->     list_to_integer(Port);
            undefined       ->    lager:error("||Fetching Env vars Failed||undefined"),
                                  8000
        end.