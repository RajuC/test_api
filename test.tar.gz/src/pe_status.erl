%% Author: hawkiwi
%% Created: Sept 9, 2011
%% Description: Builds the status page info for the push engine
-module(pe_status).

%%
%% Exported Functions
%%
-export([getNodeInfo/0, getStatusHTML/0, getConnPCs/0, getSysParams/0, getNodeInfo2/0,  getConnPCs2/0, getSysParams2/0]).

-define(PRIMARY_PE_NODE_PORT, 8002).
-define(SECONDARY_PE_NODE_PORT, 8003).
-define(PRIMARY_PC_NODE_PORT, 10103).
-define(SECONDARY_PC_NODE_PORT, 10104).

%%
%% API Functions
%%

%%
% getNodeInfo() - Returns simple info about this push engine node - name, group, and status as a JSON array
%%
getNodeInfo() ->
	NodeName = atom_to_list(node()),
	Status = "running",
	ReturnJSON = "[{\"name\":\"" ++ NodeName ++ "\", \"status\":\"" ++ Status ++ "\"}]",
	ReturnJSON.


getSysParams() ->
	MemoryDetails = erlang:memory(),
	{total, TotalSysMem} = lists:keyfind(total, 1, MemoryDetails),
	{system, UsedSysMem} = lists:keyfind(system, 1, MemoryDetails),
	{processes_used, UsedProcMem} = lists:keyfind(processes_used, 1, MemoryDetails),
	{processes, AllocProcMem} = lists:keyfind(processes, 1, MemoryDetails),
	ReturnJSON = "[{\"Registered Process Count\":\"" ++ formatInteger(length(registered()),[]) ++ "\", \"Total Allocated Memory\":\"" ++ formatInteger(TotalSysMem,[]) ++ " Bytes\", \"Memory Allocated for System\":\"" ++ formatInteger(UsedSysMem,[]) ++ " Bytes\", \"Memory Allocated for Processes\":\"" ++ formatInteger(AllocProcMem,[]) ++ " Bytes\", \"Memory Used by Processes\":\"" ++ formatInteger(UsedProcMem,[]) ++ " Bytes\"}]",
	ReturnJSON.

%%
% getStatusHTML() - Returns the HTML for the push engine status page
%%
getStatusHTML() ->
	ReturnHTMLHead = "<B>" ++ atom_to_list(node()) ++ "</B> | running <BR/><BR/>",
	%% 	Proc_TableHTML = "<TABLE border=\"2\" bgcolor=\"#EFD3D2\">" ++
	%% 						 "<TR><TD><B>Process Name</B></TD><TD><B>Process ID</B></TD><TD><B>Status</B></TD></TR>" ++
	%% 						 buildProcessTableRow(locator_gen_server, odd) ++
	%% 						 buildProcessTableRow(switch_gen_server, even) ++
	%% 						 buildProcessTableRow(pingPELoop, odd) ++
	%% 						 buildProcessTableRow(jfeeder_rip, even) ++
	%% 						 buildProcessTableRow(pc_gen_server, odd) ++
	%% 						 "</TABLE><BR/><BR/>",
	%get lists of connected nodes
	{PE_Nodes, PC_Nodes, Misc_Nodes} = getConnectedNodes(),
	%create HTML tables
	%connected push engines
	PENode_TableHTML = "<TABLE border=\"2\" bgcolor=\"#EFD3D2\">" ++
						   "<TR><TD><B>Connected Push Engines</B></TD></TR>" ++
						   buildNodeTableRows(PE_Nodes) ++
						   "</TABLE><BR/><BR/>",
	%connected push controllers
	PCNode_TableHTML = "<TABLE border=\"2\" bgcolor=\"#EFD3D2\">" ++
						   "<TR><TD><B>Connected Push Controllers</B></TD></TR>" ++
						   buildNodeTableRows(PC_Nodes) ++
						   "</TABLE><BR/><BR/>",
	%misc nodes
	MiscNode_TableHTML = "<TABLE border=\"2\" bgcolor=\"#EFD3D2\">" ++
							 "<TR><TD><B>Other Connected Nodes</B></TD></TR>" ++
							 buildNodeTableRows(Misc_Nodes) ++
							 "</TABLE><BR/><BR/>",
	
	%system info
	SysInfo_TableHTML = "<TABLE border=\"2\" bgcolor=\"#EFD3D2\">" ++
							"<TR><TD><B>System Parameter</B></TD><TD><B>Value</B></TD></TR>" ++
							buildSystemTableRows() ++
							"</TABLE><BR/><BR/>",
	
	%% 	%system memory info
	%% 	MemUtil_TableHTML = "<TABLE border=\"2\" bgcolor=\"#EFD3D2\">" ++
	%% 						 buildMemUtilTableRows() ++
	%% 						 "</TABLE><BR/><BR/>",
	
	%processor utilization info
	%% 	ProcUtil_TableHTML = "<TABLE border=\"2\" bgcolor=\"#EFD3D2\">" ++
	%% 						 buildProcUtilTableRows() ++
	%% 						 "</TABLE><BR/><BR/>",
	
	ReturnHTMLBody = PENode_TableHTML ++ PCNode_TableHTML ++ MiscNode_TableHTML ++ SysInfo_TableHTML,
	%ReturnHTMLTail = "</BODY></HTML>",
	ReturnHTMLHead ++ ReturnHTMLBody. % ++ ReturnHTMLTail.

%%
% getConnPCs() - returns a JSON-encoded list of the connected push controllers.
%%
getConnPCs() ->
	% lager:info("||Satrted getConnPCs"),
	{_PE_Nodes, PC_Nodes, _Misc_Nodes} = getConnectedNodes(),
	%return a JSON-formatted string like "[{"PCs",["pcnode1@host1","pcnode2@host2"]}]"
	case PC_Nodes of
		[] ->
			"[{\"PCs\":[]}]";
		[OneNode] ->
			"[{\"PCs\":[\"" ++ OneNode ++ "\"]}]";
		_Else ->
			"[{\"PCs\":[\"" ++ string:join(PC_Nodes, "\",\"") ++ "\"]}]"
	end.



%%
% getNodeInfo() - Returns simple info about this push engine node - name, group, and status as a JSON array
%%
getNodeInfo2() ->
	NodeName = atom_to_list(node()),
	Status = "running",
    "{\"name\":\"" ++ NodeName ++ "\", \"status\":\"" ++ Status ++ "\"}".


getSysParams2() ->
	MemoryDetails = erlang:memory(),
	{total, TotalSysMem} = lists:keyfind(total, 1, MemoryDetails),
	{system, UsedSysMem} = lists:keyfind(system, 1, MemoryDetails),
	{processes_used, UsedProcMem} = lists:keyfind(processes_used, 1, MemoryDetails),
	{processes, AllocProcMem} = lists:keyfind(processes, 1, MemoryDetails),
	ReturnJSON = "{\"Registered Process Count\":\"" ++ formatInteger(length(registered()),[]) ++ "\", \"Total Allocated Memory\":\"" ++ formatInteger(TotalSysMem,[]) ++ " Bytes\", \"Memory Allocated for System\":\"" ++ formatInteger(UsedSysMem,[]) ++ " Bytes\", \"Memory Allocated for Processes\":\"" ++ formatInteger(AllocProcMem,[]) ++ " Bytes\", \"Memory Used by Processes\":\"" ++ formatInteger(UsedProcMem,[]) ++ " Bytes\"}",
	ReturnJSON.

%%
% getConnPCs() - returns a JSON-encoded list of the connected push controllers.
%%
getConnPCs2() ->
	lager:info("||Started getConnPCs"),
	{_PE_Nodes, PC_Nodes, _Misc_Nodes} = getConnectedNodes(),
	%return a JSON-formatted string like "[{"PCs",["pcnode1@host1","pcnode2@host2"]}]"
	case PC_Nodes of
		[] ->
			"{\"PCs\":[]}";
		[OneNode] ->
			"{\"PCs\":[\"" ++ OneNode ++ "\"]}";
		_Else ->
			"{\"PCs\":[\"" ++ string:join(PC_Nodes, "\",\"") ++ "\"]}"
	end.
	% lager:info("||Return:~p.",[ReturnJSON]),
	% ReturnJSON.
%%
% Local Functions
%%

%% %%
%% % buildProcessTableRow() - Builds a single row for the child process table
%% %%
%% buildProcessTableRow(ProcessName, RowColor) ->
%% 	PID = whereis(ProcessName),
%% 	case PID of
%% 		undefined ->
%% 			PIDText = "undefined",
%% 			ProcStatus = "not running";
%% 		_ ->
%% 			PIDText = pid_to_list(PID),
%% 			case erlang:is_process_alive(PID) of
%% 				false ->
%% 				   ProcStatus = "not running";
%% 			   	true ->
%% 				   ProcStatus = "running"
%% 			end
%% 	end,
%% 	if 	RowColor == even ->
%% 			Color = "\"#EFD3D2\"";
%% 		true ->
%% 			Color = "\"#F5F5F5\""
%% 	end,
%% 	TableRow = "<TR bgcolor=" ++ Color ++ "><TD>" ++ atom_to_list(ProcessName) ++ "</TD><TD>" ++ PIDText ++ "</TD><TD>" ++ ProcStatus ++ "</TD></TR>",
%% 	TableRow.

%%
% buildNodeTableRows() - Calls buildNodeTableRows/3 to build the rows for a table of nodes
%%
buildNodeTableRows(NodeList) ->
	if length(NodeList) =:= 0 ->
		   buildNodeTableRows(["none"], odd, []);
	   true ->
		   buildNodeTableRows(NodeList, odd, [])
	end.

%%
% buildNodeTableRows() - Builds the HTML rows for a table of node names
%%
buildNodeTableRows([], _, TableRows) ->
	%already made a row for each node in list
	TableRows;
buildNodeTableRows(ListOfNodes, RowColor, TableRows) ->
	[NodeName|RestOfList] = ListOfNodes,
	%add HTML link to node's status if PE or PC node
	NodeNameLinked = addHtmlLinkToNodeName(NodeName),
	if 	RowColor == even ->
			NewTableRow = "<TR bgcolor=\"#EFD3D2\"><TD>" ++ NodeNameLinked ++ "</TD></TR>",
			buildNodeTableRows(RestOfList, odd, TableRows ++ NewTableRow);
		true ->
			NewTableRow = "<TR bgcolor=\"#F5F5F5\"><TD>" ++ NodeNameLinked ++ "</TD></TR>",
			buildNodeTableRows(RestOfList, even, TableRows ++ NewTableRow)
	end.

%%
% getConnectedNodes() - calls sortConnectedNodes() to sort the nodes into lists based on type
%%
getConnectedNodes() ->
	% lager:info("||Started getConnectedNodes"),
	ListOfNodes = nodes(connected),
	% lager:info("||ListOfNodes:~p.",[ListOfNodes]),
	if length(ListOfNodes) =:= 0 ->
		   {[],[],[],[]};
	   true ->
		   %at least one connected node
		   sortConnectedNodes(ListOfNodes, [], [], [])
	end.

%%
% sortConnectedNodes() - Sorts the passed-in list of nodes into lists by node type
%%
sortConnectedNodes([], PE_Nodes, PC_Nodes, Misc_Nodes) ->
	{PE_Nodes, PC_Nodes, Misc_Nodes};
sortConnectedNodes(ListOfNodes, PE_Nodes, PC_Nodes, Misc_Nodes) ->
	[Node|RestOfList] = ListOfNodes,
	NodeName = atom_to_list(Node),
	case NodeName of
		"rddnode" ++ RestName ->
			% lager:info("|| RestName:~p ",[RestName]),
			case RestName of
				"N" ++ _ ->
					% lager:info("|| Added in Push Controller ",[]),
					% push controller node
					NewPCList = lists:append([NodeName], PC_Nodes),
					sortConnectedNodes(RestOfList, PE_Nodes, NewPCList, Misc_Nodes);
				_ ->
					% push engine node!
					% lager:info("|| Added in Push Engine ",[]),
					NewPEList = lists:append([NodeName], PE_Nodes),
					% lager:info("||NewPEList:~p.",[NewPEList]),
					sortConnectedNodes(RestOfList, NewPEList, PC_Nodes, Misc_Nodes)
			end;
		
		_ ->
			%misc node - not one of the above classes of nodes
			NewMiscNodes =  lists:append([NodeName], Misc_Nodes),
			sortConnectedNodes(RestOfList, PE_Nodes, PC_Nodes, NewMiscNodes)
	end.

%%
% buildSystemTableRows() - Builds the HTML table rows of system data for this push controller
%%
buildSystemTableRows() ->
	NumProcRow = "<TR bgcolor=\"#F5F5F5\"><TD>Registered Processes Count</TD><TD>" ++ formatInteger(length(registered()),[]) ++ "</TD><TR>",
	MemoryDetails = erlang:memory(),
	{total, TotalSysMem} = lists:keyfind(total, 1, MemoryDetails),
	{system, UsedSysMem} = lists:keyfind(system, 1, MemoryDetails),
	{processes_used, UsedProcMem} = lists:keyfind(processes_used, 1, MemoryDetails),
	{processes, AllocProcMem} = lists:keyfind(processes, 1, MemoryDetails),
	SysMemRow = "<TR bgcolor=\"#EFD3D2\"><TD>Total Allocated Memory</TD><TD>" ++ formatInteger(TotalSysMem,[]) ++ " Bytes</TD><TR>",
	UsedSysMemRow = "<TR bgcolor=\"#F5F5F5\"><TD>Memory Allocated for System</TD><TD>" ++ formatInteger(UsedSysMem,[]) ++ " Bytes</TD><TR>",
	AllocProcMemRow = "<TR bgcolor=\"#EFD3D2\"><TD>Memory Allocated for Processes</TD><TD>" ++ formatInteger(AllocProcMem,[]) ++ " Bytes</TD><TR>",
	UsedProcMemRow = "<TR bgcolor=\"#F5F5F5\"><TD>Memory Used by Processes</TD><TD>" ++ formatInteger(UsedProcMem,[]) ++ " Bytes</TD><TR>",
	TableRows = NumProcRow ++ SysMemRow ++ UsedSysMemRow ++ AllocProcMemRow ++ UsedProcMemRow,
	TableRows.

%%
% formatInteger () - Takes a plain int and formats it as a string with commas for readability
%					NOTE: Pass an empty list "[]" as StringVal for the initial call.
%%	
formatInteger(IntVal, StringVal) ->
	if is_integer(IntVal) ->
		   if IntVal =:= 0 ->
				  %finished - return the string
				  StringVal;
			  true ->
				  %else, add three more digits to the string
				  RemVal 	= IntVal rem 1000,
				  NewIntVal = IntVal div 1000,
				  IntString =
					  if (RemVal > 99) or (NewIntVal =:= 0) ->
							 integer_to_list(RemVal);
						 (RemVal > 9) ->
							 "0" ++ integer_to_list(RemVal);
						 true ->
							 "00" ++ integer_to_list(RemVal)
					  end,
				  case StringVal of
					  [] ->
						  %first time - empty string - recurse and pass new IntString as StringVal
						  formatInteger(NewIntVal, IntString);
					  _ ->
						  %else, prepend lower digits and a comma then recurse
						  formatInteger(NewIntVal, IntString ++ "," ++ StringVal)
				  end
		   end;
	   true ->
%%%%lager:warning("||~-12w pc_status:formatInteger() was passed an invalid (non-integer) value!", [time()]),
		   "error"
	end.

%%
% buildMemUtilTableRows() - Builds the HTML table rows for the memory utilization table
%%
%% buildMemUtilTableRows() ->
%% 	MemUtilRaw = os:cmd("top"),
%% 	MemUtilTokens = string:tokens(MemUtilRaw, "\n"),
%% 	TableBody = buildUtilTableRow("", MemUtilTokens),
%% 	"<TR bgcolor=\"#EFD3D2\"><TD><B>System Memory (\"top\" Command)</B></TD></TR>" ++ TableBody.

%%
% buildProcUtilTableRows() - Builds the HTML table rows for the processor utilization table
%%
%% buildProcUtilTableRows() ->
%% 	ProcUtilRaw = os:cmd("mpstat"),
%% 	ProcUtilTokens = string:tokens(ProcUtilRaw, "\n"),
%% 	TableBody = buildUtilTableRow("", ProcUtilTokens),
%% 	"<TR bgcolor=\"#EFD3D2\"><TD><B>Processor Utilization (\"mpstat\" Command)</B></TD></TR>" ++ TableBody.
%% 	
%% %%
%% % buildUtilTableRow() - Builds an HTML table row by adding a break to the end of each of the tokens held 
%% %						in UtilTokens and concatenating them all together in a single row. 
%% % NOTE: This is a recursive function - please pass an empty string ("") for TableBody on the initial call.
%% %%
%% buildUtilTableRow(TableBody, UtilTokens) ->
%% 	case UtilTokens of
%% 		[] ->
%% 			"<TR bgcolor=\"#F5F5F5\"><TD><PRE>" ++ TableBody ++ "</PRE></TD></TR>";
%% 		[Head|Tail] ->
%% 			case Tail of
%% 				[] ->
%% 					TableBody1 = TableBody ++ Head;
%% 				_ ->
%% 					TableBody1 = TableBody ++ Head ++ "<BR/>"
%% 			end,
%% 			buildUtilTableRow(TableBody1, Tail)
%% 	end.

%%
% addHtmlLinkToNodeName() - Adds an HTML link to the node's status page for the node name given
%%
addHtmlLinkToNodeName(NodeName) ->
	case NodeName of
		"rddnodeN" ++ _ ->
			%push controller - set port based on Pri/Sec name
			AtPos = string:str(NodeName, "@") + 1,
			MachineName = string:sub_string(NodeName, AtPos),
			IntPos = string:str(NodeName, "Pri"),
			PortNumber =
				if 
					IntPos =:= 0 ->
						%secondary node - set port to 10101
						?SECONDARY_PC_NODE_PORT;
					true ->
						%primary node - set port to 10100
						?PRIMARY_PC_NODE_PORT
				end,
			"<A HREF=\"http://" ++ MachineName ++ ":" ++ integer_to_list(PortNumber) ++ "/status\">" ++
				NodeName ++ "</A>";
		"rddnode" ++ _ ->
			%push engine - set port based on 1/2 in name
			AtPos = string:str(NodeName, "@") + 1,
			MachineName = string:sub_string(NodeName, AtPos),
			IntPos = string:str(NodeName, "rddnode1"),
			PortNumber =
			if 
				IntPos =:= 0 ->
					%secondary node - set port to 8003
					?SECONDARY_PE_NODE_PORT;
				true ->
					%primary node - set port to 8002
					?PRIMARY_PE_NODE_PORT
			end,
			"<A HREF=\"http://" ++ MachineName ++ ":" ++ integer_to_list(PortNumber) ++ "/status\">" ++
				NodeName ++ "</A>";
		_ ->
			%%just return the node name with no link - not a PC or PE node
			NodeName
	end.
