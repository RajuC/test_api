%% Createded in May 2014 by Zulfiqer .

-module(admin_interface).

-behaviour(gen_server).


-export([start/0]).

-export([init/1, handle_call/3, handle_cast/2, handle_info/2,
		 terminate/2, code_change/3]).

start() ->
	Gen_server_name = 'admin_gen_server',
	gen_server:start_link({local,Gen_server_name},?MODULE,[],[]).

init(_Args) ->
	{ok,[]}.

handle_call(_Request,_From,State) ->
	{reply,[],State}.

handle_cast(_Msg, State) ->
	{noreply, State}.

%% receive message from Push Controller
%% message format {admin_info, PC_Temp_Process_ID}

handle_info({admin_info, From},State) ->
	lager:info("||handle_info received admin_info as ~p", [{admin_info, From}]),
	Status 			= pe_status:getNodeInfo2(),
	SysParams 		= pe_status:getSysParams2(),
	ConnPCs 		= pe_status:getConnPCs2(),
	ReturnJSON 		= "{\"Status\":" ++ Status ++ ", \"SysParams\":" ++ SysParams ++ ",\"ConnPCs\":" ++ ConnPCs ++ "}",
	From ! {pe_admin_info,ReturnJSON},
	lager:info("||handle_info sent ReturnJson: ~p", [ReturnJSON]),
	{noreply,State};


handle_info(_Info, State) ->
	{noreply,State}.

terminate(_Reason, _State) -> 
	ok.

code_change(_OldVsn, State, _Extra) -> 
	{ok, State}.
