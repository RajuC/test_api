-module(ws_handler).

-export([init/2,terminate/3]).
-export([websocket_handle/3]).
-export([websocket_info/3,websocket_terminate/3]).


-export([dummy_pc/0, dummy_pc_loop/2]).

-record (state,{pc_pid,
				pc_node,
				connect_timer,
				ping_timer_tpl,
				ack_timers 			= [],
				resp_timers 		= []
		}).

-include("pe_ws.hrl").



%% Websocket connection initialization
init(Req, _Opts) ->
	Path 					= cowboy_req:path(Req),
	_Host_URL 				= cowboy_req:host_url(Req),
	% lager:info("||URL: ~p Path: ~p self = ~p init websocket Req: ~p", [Host_URL, Path, self(), Req]),
%%	lager:info("||self = ~p init websocket Req: ~p ",[self(),Req]),
	DeviceParams 			= 	get_device_params(Req),
	PushId 					= 	DeviceParams#'DeviceParameters'.push_id,
	Token 					= 	DeviceParams#'DeviceParameters'.token,
	PCNode 					= 	utils:get_pc_node(PushId),	
	SMS_arrival_time 		= 	get_req_list(<<"arrival_time">>, 		Req),
	OsType 					= 	get_req_list(<<"OS_TYPE">>, 			Req),
	AppId  					= 	get_req_list(<<"APP_ID" >>, 			Req),
	AppVersion 				= 	get_req_list(<<"APP_VERSION" >>, 		Req),
 	DeviceModel 			= 	get_req_list(<<"DEVICE_MODEL" >>, 		Req),
	OsVersion 				=  	get_req_list(<<"OS_VERSION" >>, 		Req),
	AppPackage 				= 	get_req_list(<<"APP_PKG" >>, 			Req),
	AppVersionName 			=  	get_req_list(<<"APP_VERSIONNAME" >>, 	Req),
	AppVersionCode 			=  	get_req_list(<<"APP_VERSIONCODE" >>, 	Req),
	send_connect_to_pc(PCNode, DeviceParams),
	% lager:info("||Path: ~p, PushId: ~p, Token: ~p, SMS/WAP Arrival Time: ~p DeviceParams: ~p OS_TYPE ~p  APP_ID: ~p APP_VERSION: ~p  APP_PKG: ~p
	% 						APP_VERSIONNAME: ~p APP_VERSIONCODE: ~p DEVICE_MODEL: ~p OS_VERSION: ~p ",
	% 						[Path, PushId, Token, SMS_arrival_time, DeviceParams, OsType, AppId, AppVersion, DeviceModel, OsVersion]),
	lager:info("||Path: ~p, PushId: ~p, Token: ~p, SMS/WAP Arrival Time: ~p, OS_TYPE ~p, 
		APP_ID: ~p, APP_VERSION: ~p,  APP_PKG: ~p, APP_VERSIONNAME: ~p, APP_VERSIONCODE: ~p,
		DEVICE_MODEL: ~p, OS_VERSION: ~p ", [Path, PushId, Token, SMS_arrival_time, OsType,
		AppId, AppVersion, AppPackage, AppVersionName, AppVersionCode, DeviceModel, OsVersion]),
	TimerRef 				= erlang:send_after(?MVM_REGISTER_TIMEOUT, self(), connect_timeout),
	DevIdleTimeout 			=
		case cowboy_req:header(<<"api_version">>, Req) of
			undefined -> ?DEV_IDLE_TIMEOUT_INFINITE;
			API 		-> 	case binary_to_integer(API)> 0 of
								true 	-> ?DEV_IDLE_TIMEOUT;
								false 	-> ?DEV_IDLE_TIMEOUT_INFINITE
							end
		end,
	{cowboy_websocket, Req, #state{ pc_node 		= PCNode,
									connect_timer 	= TimerRef,
									ping_timer_tpl  = {undefined, DevIdleTimeout}}}.



websocket_handle({text, <<?CMD_ACK_T, Binary/binary>>}, Req,
				 State = #state{ack_timers 		= AckTimers,
				 				pc_pid 			= PCId,
				 				pc_node 		= PCNode,
				 				ping_timer_tpl 	= {DevIdleTimerRef, DevIdleTimeout} }) ->
	lager:info("||CmdAck: Binary:~p ", [Binary]),
	erlang:cancel_timer(DevIdleTimerRef),
	[CmdBin, TxidBin, UITxidBin] 	= binary:split(Binary, [?TILDA], [global]),
	Xid 							= binary_to_list(TxidBin), 
	NewAckTimers 					= cancel_timer(Xid, AckTimers),
	send_resp_to_pc(PCId, PCNode, ctrlCmdResponse, binary_to_list(CmdBin), Xid, binary_to_list(UITxidBin), ""),
	DevIdleTimerRefNew 				= erlang:send_after(DevIdleTimeout, self(), device_idle_timeout),
	{reply, {text, ?CR_T}, Req, State#state{ack_timers 		= NewAckTimers,
											ping_timer_tpl 	= {DevIdleTimerRefNew,DevIdleTimeout}}};



websocket_handle({text, <<?CMD_RSP_T, Binary/binary>>}, Req,
				  State = #state{resp_timers 	= RespTimers,
				  				 pc_pid 		= PCId,
				  				 pc_node 		= PCNode,
				  				 ping_timer_tpl = {DevIdleTimerRef,DevIdleTimeout} }) ->
	lager:info("||CmdResp: Binary:~p ", [Binary]),
	erlang:cancel_timer(DevIdleTimerRef),
	[CmdBin, RestBin1] 			= binary:split(Binary, [?TILDA]),
	[TxidBin, RestBin2] 		= binary:split(RestBin1, [?TILDA]),
	[UITxidBin, OptionalJson] 	= binary:split(RestBin2, [?TILDA]),
	Xid 						= binary_to_list(TxidBin), 
	NewRespTimers 				= cancel_timer(Xid, RespTimers),
	send_resp_to_pc(PCId, PCNode, ctrlCmdResponse, binary_to_list(CmdBin), Xid, binary_to_list(UITxidBin), binary_to_list(OptionalJson)),
	DevIdleTimerRefNew 			= erlang:send_after(DevIdleTimeout, self(), device_idle_timeout),
	{reply, {text, ?CR_T}, Req, State#state{resp_timers 	= NewRespTimers,
											ping_timer_tpl 	= {DevIdleTimerRefNew,DevIdleTimeout}}};




websocket_handle({binary, <<?SD_T, Binary/binary>>}, Req,
				  State = #state{pc_pid 		= PCId,
				  				 pc_node 		= PCNode,
				  				 ping_timer_tpl = {DevIdleTimerRef,DevIdleTimeout}}) ->
	erlang:cancel_timer(DevIdleTimerRef),
	[Seq, RestData] 			= binary:split(Binary, [?TILDA]),
	[TopPackage, ScreenData] 	= binary:split(RestData, [?TILDA]),
	% Size 						= size(ScreenData),
	send_resp_to_pc(PCId, PCNode, screenData, binary_to_list(Seq),binary_to_list(TopPackage), ScreenData),
	%lager:info("||self =~p Got Data:  ~p Seq: ~p TP:~p ", [self(),Size,Seq, TopPackage]),
	DevIdleTimerRefNew 			= erlang:send_after(DevIdleTimeout, self(), device_idle_timeout),
	{ok, Req, State#state{ping_timer_tpl={DevIdleTimerRefNew,DevIdleTimeout}}};





websocket_handle({binary, <<?SDNC_T, Binary/binary>>}, Req,
				  State = #state{pc_pid 			= PCId,
				  				 pc_node 			= PCNode,
				  				 ping_timer_tpl 	= {DevIdleTimerRef,DevIdleTimeout}}) ->
	lager:info("||SDNC: Binary:~p ", [Binary]),
	erlang:cancel_timer(DevIdleTimerRef),
	[Seq, TopPackage] 		= binary:split(Binary, [?TILDA], [global]),
	DevIdleTimerRefNew 		= erlang:send_after(DevIdleTimeout, self(), device_idle_timeout),
	send_resp_to_pc(PCId, PCNode, screenDataNoChanges, binary_to_list(Seq), binary_to_list(TopPackage)),	
	{ok, Req, State#state{ping_timer_tpl={DevIdleTimerRefNew,DevIdleTimeout}} };




websocket_handle({text, <<?DEV_MSG_T, Binary/binary>>}, Req,
				  State = #state{pc_pid 		= PCId,
				  				 pc_node 		= _PCNode,
				  				 ping_timer_tpl = {DevIdleTimerRef,DevIdleTimeout}}) ->
	lager:info("||DevMsg: Binary:~p ", [Binary]),
	erlang:cancel_timer(DevIdleTimerRef),
	PCId ! {clientMsg,Binary},
	DevIdleTimerRefNew = erlang:send_after(DevIdleTimeout, self(), device_idle_timeout),
	{ok, Req, State#state{ping_timer_tpl = {DevIdleTimerRefNew,DevIdleTimeout}} };




websocket_handle({text, <<"PingResp">>}, Req,
				  State = #state{ping_timer_tpl = {DevPingTimerRef,DevIdleTimeout}}) ->
	lager:info("||Received PingResp"),
	erlang:cancel_timer(DevPingTimerRef),
	DevIdleTimerRef = erlang:send_after(DevIdleTimeout, self(), device_idle_timeout),
	{ok, Req, State#state{ping_timer_tpl = {DevIdleTimerRef, DevIdleTimeout}}};




websocket_handle({Type, Data}, Req,
				  State = #state{ping_timer_tpl = {DevIdleTimerRef,DevIdleTimeout}}) ->
	erlang:cancel_timer(DevIdleTimerRef),
	Size = size(Data),
	lager:info("||Unknown Req Type: ~p Size: ~p Data:~p ",[Type, Size, Data]),
	DevIdleTimerRefNew = erlang:send_after(DevIdleTimeout, self(), device_idle_timeout),
	{ok, Req, State#state{ping_timer_tpl = {DevIdleTimerRefNew,DevIdleTimeout}}};




websocket_handle(Data, Req,
				 State = #state{ping_timer_tpl = {DevIdleTimerRef,DevIdleTimeout}}) ->
	lager:info("||Got Unknown Msg: ~p Size: ~p",[Data, State]),
	erlang:cancel_timer(DevIdleTimerRef),
	DevIdleTimerRefNew = erlang:send_after(DevIdleTimeout, self(), device_idle_timeout),
	{ok, Req, State#state{ping_timer_tpl = {DevIdleTimerRefNew,DevIdleTimeout}}}.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Messages

websocket_info({cr, "", PCPid, PCSite}, Req,
				State = #state{connect_timer = TimerRef, ping_timer_tpl = {_, DevIdleTimeout}}) ->
	lager:info("||Received Connect Successful PCPID: ~p. ",[PCPid]),
	if is_reference(TimerRef) -> erlang:cancel_timer(TimerRef);
	   true -> ok
	end,
	process_flag(trap_exit, true),
	link(PCPid),
	DevIdleTimerRef = erlang:send_after(DevIdleTimeout, self(), device_idle_timeout),
	{reply, {text, ?CR_T_SUCCESS}, Req,  State#state{pc_pid 		= PCPid,
													 pc_node 		= PCSite,
													 connect_timer 	= undefined,
													 ping_timer_tpl = {DevIdleTimerRef,DevIdleTimeout}}};


websocket_info({cf, ErrorCode}, Req, State) ->
	lager:info("||Received cf ErrorCode: ~p. ",[ErrorCode]),
	self() ! shutdown,
	{reply, {text, list_to_binary(lists:concat([?CF_T, ErrorCode]))}, Req, State};




websocket_info(dup_pid, Req, State) ->
	lager:info("||Received duplicate connection pid to shut down "),
	exit(self(), kill),
	{ok, Req, State};




websocket_info({'EXIT', Pid, Reason} , Req, State) ->
	lager:info("||PE got Exit from Pid: ~p. Reason:~p. LRP_PID: ~p.",
		[Pid,Reason,State#state.pc_pid]),
	if 
		Pid == State#state.pc_pid ->
			lager:info("||LRP exited. Reason:~p",[Reason]),
			self() ! shutdown;
		true ->
			noop
	end,
	{ok, Req, State};



websocket_info({sendCtrlCmdNoAck, Cmd, JsonParameters, Xid, UITxid}, Req,
				State = #state{pc_pid = PCId, pc_node = PCNode}) 				->
	%lager:info("||websocket_info:sendCtrlCmdWithNoAck||Cmd:~p, JsonParameters: ~p, Xid: ~p, UITxid: ~p.",[Cmd, JsonParameters, Xid, UITxid]),
	Command = list_to_binary(lists:concat(["CmdNoAck", ?T_L, Cmd, ?T_L,Xid, ?T_L, UITxid, ?T_L, JsonParameters])),
	if 
		Cmd /= "draw" ->
			lager:info("||sendCtrlCmdNoAck PCId: ~p PCNode: ~p ~p", [PCId, PCNode,
				list_to_binary(lists:concat(["CmdNoAck", ?T_L, Cmd, ?T_L,Xid, ?T_L, UITxid, ?T_L, JsonParameters]))]);
		true ->
			noop
	end,
	send_resp_to_pc(PCId, PCNode, ctrlCmdResponse, Cmd, Xid, UITxid, []),
	{reply, {text, Command}, Req, State};



websocket_info({sendCtrlCmdWithAck, Cmd, JsonParameters, Xid, UITxid}, Req,
				State = #state{ack_timers = AckTimers}) 						->
	Command = list_to_binary(lists:concat(["CmdWAck", ?T_L, Cmd, ?T_L,Xid, ?T_L, UITxid, ?T_L, JsonParameters])),
    if 
        Cmd /= "draw" ->
            lager:info("||websocket_info:sendCtrlCmdWithAck||Cmd:~p, JsonParameters: ~p, Xid: ~p, UITxid: ~p.",
            	[Cmd, JsonParameters, Xid, UITxid]);
        true ->
            noop
    end,
	%lager:info("||sendCtrlCmdWithAck: ~p", [Command]),
	AckTref = erlang:send_after(?ACK_TIMEOUT, self(), {ack_timeout, Xid}),
	{reply, {text, Command}, Req, State#state{ack_timers = [{Xid, AckTref} | AckTimers]}};



websocket_info({sendCtrlCmdWithData, Cmd, JsonParameters, Xid, UITxid}, Req,
				State = #state{resp_timers = RespTimers}) 						->
	Command = list_to_binary(lists:concat(["CmdWData", ?T_L, Cmd, ?T_L,Xid, ?T_L, UITxid, ?T_L, JsonParameters])),
	lager:info("||sendCtrlCmdWithData: ~p", [Command]),
	CmdTref = erlang:send_after(?CMD_TIMEOUT, self(), {cmd_timeout, Xid}),
	{reply, {text, Command}, Req, State#state{resp_timers = [{Xid, CmdTref} | RespTimers]}};



%Timeout and shutdown msgs:

websocket_info(device_idle_timeout, Req,
				State = #state{ack_timers 		= [],
							   resp_timers 		= [],
							   ping_timer_tpl 	= {_,DevIdleTimeout}} ) ->  % when ack_timers & resp_timers are empty
	lager:info("||Device Idle Timedout",[]),
	DevPingTimerRef = erlang:send_after(?DEV_PING_TIMEOUT, self(), device_ping_timeout),
	{reply, {text, <<"CmdPing">>}, Req, State#state{ping_timer_tpl = {DevPingTimerRef, DevIdleTimeout}}};



websocket_info(device_idle_timeout, Req, State = #state{ping_timer_tpl = {_,DevIdleTimeout}} ) ->    % when ack_timers or resp_timers is not empty
	lager:info("||Device Idle timedout when waiting for cmd response.",[]),
	DevIdleTimerRef = erlang:send_after(DevIdleTimeout,self(), device_idle_timeout),
	{ok ,Req, State#state{ping_timer_tpl = {DevIdleTimerRef, DevIdleTimeout}}};



websocket_info(shutdown, Req, State) ->
%	lager:info("||self = ~p websocket shutting down. Msg:~p State:~p",[self(),shutdown,State]),
	{stop, Req, State};



websocket_info({timeout, _Ref, Msg}, Req, State) ->
%	lager:info("||self = ~p websocket info timeout. Msg:~p State:~p",[self(),Msg,State]),
	self() ! shutdown,
	{reply, {text, Msg}, Req, State};



websocket_info({ack_timeout, Xid}, Req, State = #state{ack_timers = Timers}) ->
	lager:info("||Ack Timeout for :~p",[Xid]),
	send_shutdown(Xid, Timers, Req, State);	



websocket_info({cmd_timeout, Xid}, Req, State = #state{resp_timers = Timers}) ->
	lager:info("||CmdResp Timeout for :~p",[Xid]),
	send_shutdown(Xid, Timers, Req, State);	



websocket_info(connect_timeout, Req, State) ->
	lager:info("||Connection timeout",[]),
	self() ! shutdown,
	{reply, {text, ?CF_T_101}, Req, State};



websocket_info(device_ping_timeout, Req, State) ->
	lager:info("||Device Ping Timedout",[]),
	State#state.pc_pid ! {clientNotResponding,self()},
	erlang:send_after(?SHUTDOWN_TIMEOUT_AFTER_SENDING_DEVICE_UNRESPONSIVE,self(),shutdown),
	{reply, {text, <<"Closing Connection, Reason: Device unresponsive.">>}, Req, State};



websocket_info(lrp_not_found, Req, State) ->
	lager:info("||Received lrp_not_found from PC."),
	self() ! shutdown,
	{reply, {text, ?CF_T_501}, Req, State};


websocket_info(ui_terminated, Req, State) ->
	lager:info("||Received ui_terminated from PC."),
	self() ! shutdown,
	{reply, {text, <<"Closing Connection, Reason: UI Closed">>}, Req, State};


websocket_info({send, Msg}, Req, State) ->
	lager:info("||websocket info  Msg:~p State:~p",[Msg]),
	{reply, {text, Msg}, Req, State};



websocket_info(_Info, Req, State) ->
	lager:info("||websocket info  Msg:~p State:~p",[_Info,State]),
	{ok, Req, State}.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
websocket_terminate(_Reason, _Req, State) ->
	lager:info("||ws_handler websocket terminate. reason: ~p",[_Reason]),
	State#state.pc_pid ! {terminateConnection, self()}.

terminate(_Reason, _Req, State) ->
	lager:info("||self = ~p ws_handler::terminate. Reason : ~p||State: ~p ",
		[self(), _Reason, State]),
		case State#state.pc_pid of
			undefined -> noop;
			_ 		  -> State#state.pc_pid ! {terminateConnection, self()}
		end.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Hepler Functions


get_device_params(Req) ->
	#'DeviceParameters'{
						push_id 		= get_req_list(<<"mdn">>, 			Req),
						token 			= get_req_list(<<"token">>, 		Req),
						imsi 			= get_req_list(<<"imsi">>, 			Req),
						imei 			= get_req_list(<<"imei">>, 			Req),
						iccid 			= get_req_list(<<"iccid">>, 		Req),
						meid 			= get_req_list(<<"meid">>, 			Req),
						mvmVersion 		= get_req_list(<<"mvmversion">>, 	Req),
						mvsVersion 		= get_req_list(<<"mvsversion">>, 	Req),
						make 			= get_req_list(<<"make">>, 			Req),
						model 			= get_req_list(<<"model">>, 		Req),
						firmware 		= get_req_list(<<"firmware">>, 		Req),
						x_resol 		= get_req_list(<<"x">>, 			Req),
						y_resol		 	= get_req_list(<<"y">>, 			Req),
						compress 		= get_req_list(<<"cr">>, 			Req),
						featureList 	= get_req_list(<<"featurelist">>, 	Req),
						client_status 	= "clientAcceptedWSReq"
	}.

get_req_list(Type, Req) ->
	case cowboy_req:header(Type, Req) of
		undefined ->
			undefined;
		Bin ->
			binary_to_list(Bin)
	end.

send_connect_to_pc(PCNode, Parameters) ->
	{locator_gen_server, PCNode} ! {connect_request, Parameters#'DeviceParameters'.push_id, self(), Parameters}.

send_resp_to_pc(PCId, _PCNode, ctrlCmdResponse, Cmd, Xid, UITxid, OptionalJson) ->
	lager:info("||send_resp_to_pc::||PCId:~p.",[PCId]),
	PCId ! {ctrlCmdResponse,Cmd, Xid, UITxid, OptionalJson}.

send_resp_to_pc(PCId, _PCNode, screenData, Seq, TopPackage,ScreenData)	->
	Screen = #screen_data{data 		= ScreenData,
						  top_pkgid = TopPackage,
						  timestamp = utils:get_timestamp()},
	PCId ! {screenData,Seq, Screen}.

send_resp_to_pc(PCId, _PCNode, screenDataNoChanges, Seq, TopPackage)	->
	PCId ! {screenDataNoChange, Seq, TopPackage, utils:get_timestamp()}.



cancel_timer(Xid, Timers) ->
	case lists:keytake(Xid, 1, Timers) of
		{value, {Xid, TRef}, NewTimers} ->
			erlang:cancel_timer(TRef),
			NewTimers;
		false ->
			Timers
	end.


send_shutdown(Xid, Timers, Req, State) ->
	case lists:keymember(Xid, 1, Timers) of
		true ->
			State#state.pc_pid ! {clientNotResponding, self()},
			self() ! shutdown,
			{reply, {text, ?CF_T_101}, Req, State};
		false ->
			{ok, Req, State}
	end.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Test
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dummy_pc() ->
	io:format("starting dummy pc"),
	register(locator_gen_server, spawn(dummy_pc_loop, [1,undefined])).


dummy_pc_loop(Count, PePid) ->
	receive
		{connect_request, PushId, NewPePid, _Parameters} ->
			io:format("PC:Device connected: ~p Pid:~p ",[PushId, NewPePid]),
			NewPePid ! {lrp_resp, self()},
			timer:send_after(10000, timeout),
			dummy_pc_loop(Count, NewPePid);
		
		{ctrlCmdResponse,Cmd, Xid, UITxid, OptionalJson} ->
			timer:send_after(10000, timeout),
			io:format("Resp recieved: ~p ~p ~p ~p", [Cmd, Xid, UITxid, OptionalJson] ),
			dummy_pc_loop(Count, PePid);
		
		{screenData,Seq,TopPackage,Timestamp, _ScreenData} ->
			io:format("Consumed Screen Data: ~p ~p ~p",[Seq,TopPackage, Timestamp]),
			dummy_pc_loop(Count, PePid);
		
		{screenDataNoChange, Seq, TopPackage, TimeStamp} ->
			io:format("No screen change: ~p ~p ~p",[Seq,TopPackage, TimeStamp]),
			dummy_pc_loop(Count, PePid);
		timeout ->
			PePid ! {sendCtrlCmdNoAck, integer_to_list(Count, 10), "{\"test\":test}", Count, Count},
			dummy_pc_loop(Count+1, PePid);
		close ->
			ok;
		UnknownData ->
			io:format("Received unknown: ~p",[UnknownData])
	end.
